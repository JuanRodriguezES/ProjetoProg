Em geral os objetivos foram cumpridos , tentei ser o mais eficiente possível na escrita do código , mas certamente poderia ter sido mais ainda , até ao momento penso que escolhi os métodos corretos a meu ver para abordar o problema.
A formatação da board de jogo foi o que mais me desafiou , pois não tinha feito nada parecido ainda , por isso não tenho a certeza se o código que fiz em relação à board não podia ser melhorado.
Em relação ao jogo em si , penso que captei todas as suas regras , seja a possibilidade de o player poder desistir , seja a possibilidade de movimentos como o de capturar todas as sementes do oponente não ser possível. Ainda , assumi que os jogadores podem fazer "sowing" numa casa com 0 sementes e podem ter 0 sementes em todas as suas casas , com exceção do movimento que já referi.
Inclui código para colorar as sementes(números) e tomei a liberdade de fazer a formatação da board de jogo à minha vontade tal como foi dito no enunciado.

João Silva , up201906478