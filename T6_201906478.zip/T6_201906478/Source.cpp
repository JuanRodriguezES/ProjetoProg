#define NOMINMAX

#include <iostream>
#include <vector>
#include <iomanip>
#include <string>
#include <Windows.h>



using namespace std;


int player_turn = 0; // VARI�VEL GLOBAL para decidir os turnos / Decide if its upper player turn or lower player turn

void draw_board(vector<int>& player); 
char letra1(int title);
char letra2(int title);
void play(vector<int>& player);


int main()
{
	vector<int> player = {4,4,4,4,4,4,0,0,4,4,4,4,4,4};//VETOR DE CASAS DE JOGO 
															// OS ZEROS REPRESENTAM CASAS DE SCORE DOS PLAYERS



	int op = 0;


	cout << "****** WELCOME TO THE OWARE GAME ******" << "\n\n";

	cout << "****** RULES ******" << "\n\n";

	cout << "Players take turns moving the seeds. On a turn, a player chooses one of the six houses under their control.\n";
	cout << "The player removes all seeds from that house, and distributes them, dropping one in each house counter-clockwise from this house.\n";
	cout << "Seeds are not distributed into the end scoring houses, nor into the house drawn from.\n";
	cout << "The starting house is always left empty; if it contained 12 (or more) seeds, it is skipped, and the twelfth seed is placed in the next house.\n";
	cout << "Capturing occurs only when a player brings the count of an opponent's house to exactly two or three with the final seed he sowed in that turn.\n";
	cout << "This always captures the seeds in the corresponding house, and possibly more.\n";
	cout << "If the previous-to-last seed also brought an opponent's house to two or three, these are captured as well.\n\n";
	cout << "****************************\n\n\n";


	while (std::cout << "Enter 1/2 for play/quit\n" && (!(std::cin >> op) || op > 2 || op < 1)) {
		std::cin.clear(); //clear bad input flag
		std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); //discard input
		std::cout << "Invalid input; please re-enter.\n";
	}

	if (op == 2) return 0;

	else if (op == 1)
	{
		draw_board(player);
	}



	return 0;
}

void draw_board(vector<int>& player) //Fun��o que recebe o vetor que cont�m o conte�do(seeds) de cada casa
//n�o retorna nenhum valor , apenas d� display ao board de jogo.
{
	string line(9, '*');

	string secondline(9, ' ');

	secondline[0] = '*';

	secondline[8] = '*';

	const int heigth = 5;

	//CAIXAS DO PLAYER1

	for (int title = 0; title < player.size()/2; title++) //Colocar o nome em cima de cada caixa de jogo do player1
	{
		if (title == 0)
		{
			cout << "ScoreUP"; // Primeira caixa � o score dos jogadores
		}

		else if (title == 1)
			cout << setw(12) << letra1(title);

		else
			cout << setw(11) << letra1(title);

		if (title == 6)
			cout << "\n";

	}
	for (int i = 0; i < player.size()/2; i++)
	{
		if (i == 0) cout << line << "     ";
		else cout << line << "  ";


	}
	cout << "\n";
	for (int i = 0; i < heigth / 2; i++)
	{
		for (int j = 0; j < player.size()/2; j++)
		{
			if (j == 0) cout << secondline << "     ";
			else cout << secondline << "  ";
			if (j == player.size()/2 - 1)
				cout << "\n";

		}

	}
	HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
	for (int i = 6; i >= 0; i--)
	{

		cout << "*   ";
		SetConsoleTextAttribute(hConsole, 6);
		cout << player[i]; 
		SetConsoleTextAttribute(hConsole, 15);
		if (i == 6)
		{
			if(player[i] < 10) cout << "   *" << "     ";

			else cout << "  *" << "     ";
		}
		else
		{
			if (player[i] < 10)
				cout << "   *" << "  ";
			else
			{
				cout << "  *" << "  ";
			}
		}

		if (i == 0)
			cout << "\n";

	}

	for (int i = 0; i < heigth / 2; i++)
	{
		for (int j = 0; j < player.size()/2; j++)
		{
			if (j == 0) cout << secondline << "     ";
			else cout << secondline << "  ";

			if (j == player.size()/2 - 1)
				cout << "\n";

		}

	}

	for (int i = 0; i < player.size()/2; i++)
	{
		if (i == 0) cout << line << "     ";
		else cout << line << "  ";

		if (i == player.size()/2 - 1)
			cout << "\n\n";
	}






	//caixas do PLAYER2

	for (int i = 7; i < player.size(); i++)
	{
		if (i == 7) cout << line << "     ";

		else cout << line << "  ";


	}
	cout << "\n";
	for (int i = 0; i < heigth / 2; i++)
	{
		for (int j = 7; j < player.size(); j++)
		{
			if (j == 7) cout << secondline << "     ";
			else cout << secondline << "  ";
			if (j == player.size() - 1)
				cout << "\n";

		}

	}
	for (int i = 7; i < player.size(); i++)
	{

		cout << "*   ";
		SetConsoleTextAttribute(hConsole, 11);
		cout << player[i];
		SetConsoleTextAttribute(hConsole, 15);
		if (i == 7)
		{
			if (player[i] < 10) cout << "   *" << "     ";

			else cout << "  *" << "     ";
		}
		else
		{
			if (player[i] < 10)
				cout << "   *" << "  ";
			else
			{
				cout << "  *" << "  ";
			}
		}

		if (i == player.size() - 1)
			cout << "\n";

	}


	for (int i = 0; i < heigth / 2; i++)
	{
		for (int j = 7; j < player.size(); j++)
		{
			if (j == 7) cout << secondline << "     ";
			else cout << secondline << "  ";
			if (j == player.size() - 1)
				cout << "\n";

		}

	}

	for (int i = 7; i < player.size(); i++)
	{
		if (i == 7) cout << line << "     ";
		else cout << line << "  ";

		if (i == player.size() - 1)
			cout << "\n";
	}


	for (int title = 7; title < player.size(); title++) //Colocar o nome em cima de cada caixa de jogo do player1
	{
		if (title == 7)
		{
			cout << "ScoreLP"; // Primeira caixa � o score dos jogadores
		}

		else if (title == 8)
			cout << setw(12) << letra2(title);

		else
			cout << setw(11) << letra2(title);

		if (title == 13)
			cout << "\n\n";

	}

	play(player);

	return;

}

char letra1(int title) //par�metro: inteiro que varia entre 1 e 6 que s�o as casas do UpperPlayer ; 
//Returna um char que vai ser displayed pela fun��o draw board;
{
	switch (title)
	{
	case 1:
		return 'f';
	case 2:
		return 'e';
	case 3:
		return 'd';
	case 4:
		return 'c';
	case 5:
		return 'b';
	case 6:
		return 'a';
	}

	return 'z';
}
char letra2(int title) //par�metro : recebe um inteiro varia entre 8 e 13 , representam as casas dos LowerPlayer que variam entre A e F;
// return um char , neste caso , o nome de casa do LowerPlayer , char pode ser A,B,C,D,E,F;
{
	switch (title)
	{
	case 8:
		return 'A';
	case 9:
		return 'B';
	case 10:
		return 'C';
	case 11:
		return 'D';
	case 12:
		return 'E';
	case 13:
		return 'F';
	}

	return 'z';
}

void play(vector<int>& player) //Decide de quem � o turno, e percorre todas as casas dos jogadores
//Consoante as sementes capturadas por cada jogador , decide se o jogo termina ou n�o.
//recebe como par�metro o vetor que cont�m as sementes em cada casa de cada jogador.
//N�o retorna valor , chama a fun��o drawboard() para atualizar a board de jogo na consola.
{
	int seeds;

	char house;

	if (player[6] >= 25 && player[7] < 25)
	{
		cout << "\n\n";
		cout << "****** Upper player won the Game by capturing 25 or more seeds ******" << endl;
	}
	else if (player[7] >= 25 && player[6] < 25)
	{
		cout << "\n\n";
		cout << "****** Lower player won the Game by capturing 25 or more seeds ******" << endl;
	}
	else if (player[7] == 24 && player[6] == 24)
	{
		cout << "\n\n";
		cout << "****** It's a Draw , both player's captured 24 seeds ******" << endl;
	}

	while (player[6] < 25 && player[7] < 25 && !(player[6] == 24 && player[7] == 24))
	{
		if (player_turn % 2 == 0)
		{
			cout << "Upper player it's your turn , choose a house , be careful with upper and lower letters  (Enter 'q' to forfeit the game)\n\n";

			cin >> house;

			while (house != 'a' && house != 'b' && house != 'c' && house != 'd' && house != 'e' && house != 'f' && house != 'q')
			{
				cin.clear(); //clear bad input flag
				cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); //discard input
				cout << "Invalid input; please re-enter.\n";
				cin >> house;
			}

			if (house == 'q')
			{
				cout << "Lower player has won the game by withdrawal\n\n";
				exit(0);
			}

			if (house == 'a')
			{
				seeds = player[0];
				player[0] = 0;
				while (seeds != 0) //Condi��o de term�no
				{
					for (int i = 1; i < player.size(); i++) //Distribuir as sementes pelas casas
					{
						if (i == 6 || i == 7 || i == 0) continue;
						player[i]++;
						seeds--;
						if (i == 13) i = -1;
						if (seeds == 0)
						{
							if (i >= 8 && i <= 13) // capture the seeds to the score house of the Upper Player
							{
								for (i; i >= 8; i--) //Current/Previous-to-last house 
								{
									if (i == 13 && (player[12] == 2 || player[12] == 3) && (player[11] == 2 || player[11] == 3) && (player[10] == 2 || player[10] == 3) && (player[9] == 2 || player[9] == 3) && (player[8] == 2 || player[8] == 3))
										break; //Forfeit the move if the player can capture all the seeds from the opponent
									if (player[i] == 3 || player[i] == 2)
									{
										player[6] += player[i];
										player[i] = 0;
									}
									else
										break;
								}

							}
							break;
						}
							
					}
				}
				player_turn++;
				cout << "The Upper player has captured total of " << player[6] << " seeds. \n\n";
				draw_board(player);
			}

			if (house == 'b')
			{
				seeds = player[1];
				player[1] = 0;
				while (seeds != 0) //Condi��o de term�no
				{
					for (int i = 2; i < player.size(); i++) //Distribuir as sementes pelas casas
					{
						if (i == 6 || i == 7 || i == 1) continue;
						player[i]++;
						seeds--;
						if (i == 13) i = -1;
						if (seeds == 0)
						{
							if (i >= 8 && i <= 13) // capture the seeds to the score house of the Upper Player
							{
								if (i == 13 && (player[12] == 2 || player[12] == 3) && (player[11] == 2 || player[11] == 3) && (player[10] == 2 || player[10] == 3) && (player[9] == 2 || player[9] == 3) && (player[8] == 2 || player[8] == 3))
									break; //Forfeit the move if the player can capture all the seeds from the opponent
								for (i; i >= 8; i--) //Current/Previous-to-last house 
								{
									if (player[i] == 3 || player[i] == 2)
									{
										player[6] += player[i];
										player[i] = 0;
									}
									else
										break;
								}

							}

							break;
						}
						
					}
				}
				player_turn++;
				cout << "The Upper player has captured total of " << player[6] << " seeds. \n\n";
				draw_board(player);
			}

			if (house == 'c')
			{
				seeds = player[2];
				player[2] = 0;
				while (seeds != 0) //Condi��o de term�no
				{
					for (int i = 3; i < player.size(); i++) //Distribuir as sementes pelas casas
					{
						if (i == 6 || i == 7 || i == 2) continue;
						player[i]++;
						seeds--;
						if (i == 13) i = -1;
						if (seeds == 0)
						{
							if (i >= 8 && i <= 13) // capture the seeds to the score house of the Upper Player
							{
								if (i == 13 && (player[12] == 2 || player[12] == 3) && (player[11] == 2 || player[11] == 3) && (player[10] == 2 || player[10] == 3) && (player[9] == 2 || player[9] == 3) && (player[8] == 2 || player[8] == 3))
									break; //Forfeit the move if the player can capture all the seeds from the opponent
								for (i; i >= 8; i--) //Current/Previous-to-last house 
								{
									if (player[i] == 3 || player[i] == 2)
									{
										player[6] += player[i];
										player[i] = 0;
									}
									else
										break;
								}

							}

							break;
						}
					}
				}
				player_turn++;
				cout << "The Upper player has captured total of " << player[6] << " seeds. \n\n";
				draw_board(player);
			}

			if (house == 'd')
			{
				seeds = player[3];
				player[3] = 0;
				while (seeds != 0) //Condi��o de term�no
				{
					for (int i = 4; i < player.size(); i++) //Distribuir as sementes pelas casas
					{
						if (i == 6 || i == 7 || i == 3) continue;
						player[i]++;
						seeds--;
						if (i == 13) i = -1;
						if (seeds == 0)
						{
							if (i >= 8 && i <= 13) // capture the seeds to the score house of the Upper Player
							{
								for (i; i >= 8; i--) //Current/Previous-to-last house 
								{
									if (i == 13 && (player[12] == 2 || player[12] == 3) && (player[11] == 2 || player[11] == 3) && (player[10] == 2 || player[10] == 3) && (player[9] == 2 || player[9] == 3) && (player[8] == 2 || player[8] == 3))
										break; //Forfeit the move if the player can capture all the seeds from the opponent
									if (player[i] == 3 || player[i] == 2)
									{
										player[6] += player[i];
										player[i] = 0;
									}
									else
										break;
								}

							}
							break;
						}
					}
				}
				player_turn++;
				cout << "The Upper player has captured total of " << player[6] << " seeds. \n\n";
				draw_board(player);
			}

			if (house == 'e')
			{
				seeds = player[4];
				player[4] = 0;
				while (seeds != 0) //Condi��o de term�no
				{
					for (int i = 5; i < player.size(); i++) //Distribuir as sementes pelas casas
					{
						if (i == 6 || i == 7 || i == 4) continue;
						player[i]++;
						seeds--;
						if (i == 13) i = -1;
						if (seeds == 0)
						{
							if (i >= 8 && i <= 13) // capture the seeds to the score house of the Upper Player
							{
								for (i; i >= 8; i--) //Current/Previous-to-last house 
								{
									if (i == 13 && (player[12] == 2 || player[12] == 3) && (player[11] == 2 || player[11] == 3) && (player[10] == 2 || player[10] == 3) && (player[9] == 2 || player[9] == 3) && (player[8] == 2 || player[8] == 3))
										break; //Forfeit the move if the player can capture all the seeds from the opponent
									if (player[i] == 3 || player[i] == 2)
									{
										player[6] += player[i];
										player[i] = 0;
									}
									else
										break;
								}

							}
							break;
						}
					}
				}
				player_turn++;
				cout << "The Upper player has captured total of " << player[6] << " seeds. \n\n";
				draw_board(player);
			}

			if (house == 'f')
			{
				seeds = player[5];
				player[5] = 0;
				while (seeds != 0) //Condi��o de term�no
				{
					for (int i = 6; i < player.size(); i++) //Distribuir as sementes pelas casas
					{
						if (i == 6 || i == 7 || i == 5) continue;
						player[i]++;
						seeds--;
						if (i == 13) i = -1;
						if (seeds == 0)
						{

							if (i >= 8 && i <= 13) // capture the seeds to the score house of the Upper Player
							{
								if (i == 13 && (player[12] == 2 || player[12] == 3) && (player[11] == 2 || player[11] == 3) && (player[10] == 2 || player[10] == 3) && (player[9] == 2 || player[9] == 3) && (player[8] == 2 || player[8] == 3))
									break; //Forfeit the move if the player can capture all the seeds from the opponent
								for (i; i >= 8; i--) //Current/Previous-to-last house 
								{
									if (player[i] == 3 || player[i] == 2)
									{
										player[6] += player[i];
										player[i] = 0;
									}
									else
										break;
								}

							}
							break;
						}
					}
				}
				player_turn++;
				cout << "The Upper player has captured total of " << player[6] << " seeds. \n\n";
				draw_board(player);
			}


		}
		else
		{

			cout << "Lower player it's your turn , choose a house , be careful with upper and lower letters   (Enter 'Q' to forfeit the game)\n\n";

			cin >> house;

			while (house != 'A' && house != 'B' && house != 'C' && house != 'D' && house != 'E' && house != 'F' && house != 'Q')
			{
				cin.clear(); //clear bad input flag
				cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); //discard input
				cout << "Invalid input; please re-enter.\n";
				cin >> house;
			}

			if (house == 'Q')
			{
				cout << "Upper player has won the game by withdrawal\n\n";
				exit(0);
			}


			if (house == 'A')
			{
				seeds = player[8];
				player[8] = 0;
				while (seeds != 0) //Condi��o de term�no
				{
					for (int i = 9; i < player.size(); i++) //Distribuir as sementes pelas casas
					{
						if (i == 6 || i == 7 || i == 8) continue;
						player[i]++;
						seeds--;
						if (i == 13) i = -1;
						if (seeds == 0)
						{
							if (i >= 0 && i <= 5) // capture the seeds to the score house of the Upper Player
							{
								if (i == 5 && (player[4] == 2 || player[4] == 3) && (player[3] == 2 || player[3] == 3) && (player[2] == 2 || player[2] == 3) && (player[1] == 2 || player[1] == 3) && (player[0] == 2 || player[0] == 3))
									break; //Forfeit the move if the player can capture all the seeds from the opponent
								for (i; i >= 0 ; i--) //Current/Previous-to-last house 
								{
									if (player[i] == 3 || player[i] == 2)
									{
										player[7] += player[i];
										player[i] = 0;
									}
									else
										break;
								}

							}
							break;
						}
					}
				}
				player_turn++;
				cout << "The Lower player has captured total of " << player[7] << " seeds. \n\n";
				draw_board(player);
			}

			if (house == 'B')
			{
				seeds = player[9];
				player[9] = 0;
				while (seeds != 0) //Condi��o de term�no
				{
					for (int i = 10; i < player.size(); i++) //Distribuir as sementes pelas casas
					{
						if (i == 6 || i == 7 || i == 9) continue;
						player[i]++;
						seeds--;
						if (i == 13) i = -1;
						if (seeds == 0)
						{
							if (i >= 0 && i <= 5) // capture the seeds to the score house of the Upper Player
							{

								for (i; i >= 0; i--) //Current/Previous-to-last house 
								{
									if (i == 5 && (player[4] == 2 || player[4] == 3) && (player[3] == 2 || player[3] == 3) && (player[2] == 2 || player[2] == 3) && (player[1] == 2 || player[1] == 3) && (player[0] == 2 || player[0] == 3))
										break; //Forfeit the move if the player can capture all the seeds from the opponent
									if (player[i] == 3 || player[i] == 2)
									{
										player[7] += player[i];
										player[i] = 0;
 									}
									else
										break;
								}

							}

							break;
						}
					}
				}
				player_turn++;
				cout << "The Lower player has captured total of " << player[7] << " seeds. \n\n";
				draw_board(player);
			}

			if (house == 'C')
			{
				seeds = player[10];
				player[10] = 0;
				while (seeds != 0) //Condi��o de term�no
				{
					for (int i = 11; i < player.size(); i++) //Distribuir as sementes pelas casas
					{
						if (i == 6 || i == 7 || i == 10) continue;
						player[i]++;
						seeds--;
						if (i == 13) i = -1;
						if (seeds == 0)
						{
							if (i >= 0 && i <= 5) // capture the seeds to the score house of the Upper Player
							{
								for (i; i >= 0; i--) //Current/Previous-to-last house 
								{
									if (i == 5 && (player[4] == 2 || player[4] == 3) && (player[3] == 2 || player[3] == 3) && (player[2] == 2 || player[2] == 3) && (player[1] == 2 || player[1] == 3) && (player[0] == 2 || player[0] == 3))
										break; //Forfeit the move if the player can capture all the seeds from the opponent
									if (player[i] == 3 || player[i] == 2)
									{
										player[7] += player[i];
										player[i] = 0;
									}
									else
										break;
								}

							}
							break;
						}
					}
				}
				player_turn++;
				cout << "The Lower player has captured total of " << player[7] << " seeds. \n\n";
				draw_board(player);
			}

			if (house == 'D')
			{
				seeds = player[11];
				player[11] = 0;
				while (seeds != 0) //Condi��o de term�no
				{
					for (int i = 12; i < player.size(); i++) //Distribuir as sementes pelas casas
					{
						if (i == 6 || i == 7 || i == 11) continue;
						player[i]++;
						seeds--;
						if (i == 13) i = -1;
						if (seeds == 0)
						{
							if (i >= 0 && i <= 5) // capture the seeds to the score house of the Upper Player
							{
								for (i; i >= 0; i--) //Current/Previous-to-last house 
								{
									if (i == 5 && (player[4] == 2 || player[4] == 3) && (player[3] == 2 || player[3] == 3) && (player[2] == 2 || player[2] == 3) && (player[1] == 2 || player[1] == 3) && (player[0] == 2 || player[0] == 3))
										break; //Forfeit the move if the player can capture all the seeds from the opponent
									if (player[i] == 3 || player[i] == 2)
									{
										player[7] += player[i];
										player[i] = 0;
									}
									else
										break;
								}

							}
							break;
						}
					}
				}
				player_turn++;
				cout << "The Lower player has captured total of " << player[7] << " seeds. \n\n";
				draw_board(player);
			}

			if (house == 'E')
			{
				seeds = player[12];
				player[12] = 0;
				while (seeds != 0) //Condi��o de term�no
				{
					for (int i = 13; i < player.size(); i++) //Distribuir as sementes pelas casas
					{
						if (i == 6 || i == 7 || i == 12) continue;
						player[i]++;
						seeds--;
						if (i == 13) i = -1;
						if (seeds == 0)
						{
							if (i >= 0 && i <= 5) // capture the seeds to the score house of the Upper Player
							{
								for (i; i >= 0; i--) //Current/Previous-to-last house 
								{
									if (i == 5 && (player[4] == 2 || player[4] == 3) && (player[3] == 2 || player[3] == 3) && (player[2] == 2 || player[2] == 3) && (player[1] == 2 || player[1] == 3) && (player[0] == 2 || player[0] == 3))
										break; //Forfeit the move if the player can capture all the seeds from the opponent
									if (player[i] == 3 || player[i] == 2)
									{
										player[7] += player[i];
										player[i] = 0;
									}
									else
										break;
								}

							}

							break;
						}
					}
				}
				player_turn++;
				cout << "The Lower player has captured total of " << player[7] << " seeds. \n\n";
				draw_board(player);
			}

			if (house == 'F')
			{
				seeds = player[13];
				player[13] = 0;
				while (seeds != 0) //Condi��o de term�no
				{
					for (int i = 0; i < player.size(); i++) //Distribuir as sementes pelas casas
					{
						if (i == 6 || i == 7) continue;
						if (i == 13) i = 0;
						player[i]++;
						seeds--;
						if (seeds == 0)
						{
							if (i >= 0 && i <= 5) // capture the seeds to the score house of the Upper Player
							{
								for (i; i >= 0; i--) //Current/Previous-to-last house 
								{
									if (i == 5 && (player[4] == 2 || player[4] == 3) && (player[3] == 2 || player[3] == 3) && (player[2] == 2 || player[2] == 3) && (player[1] == 2 || player[1] == 3) && (player[0] == 2 || player[0] == 3))
										break; //Forfeit the move if the player can capture all the seeds from the opponent
									if (player[i] == 3 || player[i] == 2)
									{
										player[7] += player[i];

										player[i] = 0;
									}
									else
										break;
								}

							}

							break;
						}
					}
				}
				player_turn++;
				cout << "The Lower player has captured total of " << player[7] << " seeds. \n\n";
				draw_board(player);
			}
		}
	}
}